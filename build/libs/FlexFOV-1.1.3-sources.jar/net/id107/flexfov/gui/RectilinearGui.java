package net.id107.flexfov.gui;

import net.id107.flexfov.projection.Projection;
import net.id107.flexfov.projection.Rectilinear;
import net.minecraft.class_437;

public class RectilinearGui extends SettingsGui {

	public RectilinearGui(class_437 parent) {
		super(parent);
		Projection.setProjection(new Rectilinear());
	}
}
