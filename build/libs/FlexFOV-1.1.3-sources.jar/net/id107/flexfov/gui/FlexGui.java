package net.id107.flexfov.gui;

import net.id107.flexfov.ConfigManager;
import net.id107.flexfov.projection.Flex;
import net.id107.flexfov.projection.Projection;
import net.minecraft.class_2585;
import net.minecraft.class_4067;
import net.minecraft.class_437;

public class FlexGui extends SettingsGui {
	
	public FlexGui(class_437 parent) {
		super(parent);
		Projection.setProjection(new Flex());
	}
	
	@Override
	protected void method_25426() {
		super.method_25426();
		
		class_4067 FOV = new class_4067("flexFov", 0, 360, 1,
				(gameOptions) -> {return Projection.getProjection().getFovX();},
				(gameOptions, number) -> {Projection.fov = number; ConfigManager.saveConfig();},
				(gameOptions, doubleOption) -> {return new class_2585("FOV: " + (int)Projection.getProjection().getFovX());});
		method_25411(FOV.method_18520(field_22787.field_1690, field_22789 / 2 - 180, field_22790 / 6 + 36, 360));
	}
}
