package net.id107.flexfov.gui;

import net.id107.flexfov.ConfigManager;
import net.id107.flexfov.gui.advanced.AdvancedGui;
import net.minecraft.class_2585;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5244;

public abstract class SettingsGui extends class_437 {

	protected final class_437 parentScreen;
	
	public static int currentGui = 1;
	
	public SettingsGui(class_437 parent) {
		super(new class_2585("Flex FOV Settings"));
		parentScreen = parent;
		ConfigManager.saveConfig();
	}
	
	public static SettingsGui getGui(class_437 parent) {
		switch (currentGui) {
		case 0:
		default:
			return new RectilinearGui(parent);
		case 1:
			return new FlexGui(parent);
		case 2:
			return AdvancedGui.getGui(parent);
		}
	}
	
	@Override
	protected void method_25426() {
		class_4185 button = new class_4185(field_22789 / 2 - 190, field_22790 / 6 - 12, 120, 20,
				new class_2585("Default"), (buttonWidget) -> {
					currentGui = 0;
					field_22787.method_1507(new RectilinearGui(parentScreen));
		});
		if (this instanceof RectilinearGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 - 60, field_22790 / 6 - 12, 120, 20,
				new class_2585("Flex"), (buttonWidget) -> {
					currentGui = 1;
					field_22787.method_1507(new FlexGui(parentScreen));
				});
		if (this instanceof FlexGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 + 70, field_22790 / 6 - 12, 120, 20,
				new class_2585("Advanced"), (buttonWidget) -> {
					currentGui = 2;
					field_22787.method_1507(AdvancedGui.getGui(parentScreen));
				});
		if (this instanceof AdvancedGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		method_25411(new class_4185(this.field_22789 / 2 - 100, this.field_22790 / 6 + 168, 200, 20, class_5244.field_24334, (buttonWidget) -> {
			field_22787.method_1507(parentScreen);
		}));
	}
	
	@Override
	public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
		this.method_25420(matrices);
		class_332.method_27534(matrices, this.field_22793, this.field_22785, this.field_22789 / 2, 15, 16777215);
		super.method_25394(matrices, mouseX, mouseY, delta);
	}
}
