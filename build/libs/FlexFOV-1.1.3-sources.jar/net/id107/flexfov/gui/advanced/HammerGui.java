package net.id107.flexfov.gui.advanced;

import net.id107.flexfov.ConfigManager;
import net.id107.flexfov.projection.Hammer;
import net.id107.flexfov.projection.Projection;
import net.minecraft.class_2585;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class HammerGui extends AdvancedGui {

	public HammerGui(class_437 parent) {
		super(parent);
		Projection.setProjection(new Hammer());
	}
	
	@Override
	protected void method_25426() {
		super.method_25426();
		
		method_25411(new class_4185(field_22789 / 2 - 155, field_22790 / 6 + 84, 150, 20,
				new class_2585("Background Color: " + (Projection.skyBackground ? "Sky" : "Black")), (buttonWidget) -> {
					Projection.skyBackground = !Projection.skyBackground;
					buttonWidget.method_25355(new class_2585("Background Color: " + (Projection.skyBackground ? "Sky" : "Black")));
					ConfigManager.saveConfig();
				}));
	}
}
