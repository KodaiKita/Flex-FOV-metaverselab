package net.id107.flexfov.gui.advanced;

import net.id107.flexfov.ConfigManager;
import net.id107.flexfov.gui.SettingsGui;
import net.id107.flexfov.projection.Projection;
import net.minecraft.class_2585;
import net.minecraft.class_4067;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AdvancedGui extends SettingsGui {

	public static int currentGui = 5;
	
	public AdvancedGui(class_437 parent) {
		super(parent);
	}
	
	public static AdvancedGui getGui(class_437 parent) {
		switch(currentGui) {
		case 0:
		default:
			return new CubicGui(parent);
		case 1:
			return new HammerGui(parent);
		case 2:
			return new PaniniGui(parent);
		case 3:
			return new CylinderGui(parent);
		case 4:
			return new FisheyeGui(parent);
		case 5:
			return new EquirectangularGui(parent);
		}
	}
	
	@Override
	protected void method_25426() {
		super.method_25426();
		
		class_4185 button = new class_4185(field_22789 / 2 - 180, field_22790 / 6 + 12, 100, 20,
				new class_2585("Cubic"), (buttonWidget) -> {
					currentGui = 0;
					field_22787.method_1507(new CubicGui(parentScreen));
		});
		if (this instanceof CubicGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 - 50, field_22790 / 6 + 12, 100, 20,
				new class_2585("Hammer"), (buttonWidget) -> {
					currentGui = 1;
					field_22787.method_1507(new HammerGui(parentScreen));
				});
		if (this instanceof HammerGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 + 80, field_22790 / 6 + 12, 100, 20,
				new class_2585("Panini"), (buttonWidget) -> {
					currentGui = 2;
					field_22787.method_1507(new PaniniGui(parentScreen));
				});
		if (this instanceof PaniniGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 - 180, field_22790 / 6 + 36, 100, 20,
				new class_2585("Cylinder"), (buttonWidget) -> {
					currentGui = 3;
					field_22787.method_1507(new CylinderGui(parentScreen));
				});
		if (this instanceof CylinderGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 - 50, field_22790 / 6 + 36, 100, 20,
				new class_2585("Fisheye"), (buttonWidget) -> {
					currentGui = 4;
					field_22787.method_1507(new FisheyeGui(parentScreen));
				});
		if (this instanceof FisheyeGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 + 80, field_22790 / 6 + 36, 100, 20,
				new class_2585("Equirectangular"), (buttonWidget) -> {
					currentGui = 5;
					field_22787.method_1507(new EquirectangularGui(parentScreen));
				});
		if (this instanceof EquirectangularGui) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		if (!(this instanceof CubicGui)) {
			class_4067 zoom = new class_4067("zoom", -2, 2, 0.05f,
					(gameOptions) -> {return (double) Projection.zoom;},
					(gameOptions, number) -> {Projection.zoom = (float)(double)number; ConfigManager.saveConfig();},
					(gameOptions, doubleOption) -> {return new class_2585(String.format("Zoom: %.2f", Projection.zoom));});
			method_25411(zoom.method_18520(field_22787.field_1690, field_22789 / 2 + 5, field_22790 / 6 + 84, 150));
		}
		
		method_25411(new class_4185(field_22789 / 2 + 5, field_22790 / 6 + 108, 150, 20,
				new class_2585("Resize Gui: " + (Projection.resizeGui ? "ON" : "OFF")), (buttonWidget) -> {
					Projection.resizeGui = !Projection.resizeGui;
					buttonWidget.method_25355(new class_2585("Resize Gui: " + (Projection.resizeGui ? "ON" : "OFF")));
				}));
	}
}
