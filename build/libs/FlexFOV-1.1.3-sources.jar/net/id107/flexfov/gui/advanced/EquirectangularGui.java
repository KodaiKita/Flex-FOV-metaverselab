package net.id107.flexfov.gui.advanced;

import net.id107.flexfov.ConfigManager;
import net.id107.flexfov.projection.Equirectangular;
import net.id107.flexfov.projection.Projection;
import net.minecraft.class_2585;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class EquirectangularGui extends AdvancedGui {

	public EquirectangularGui(class_437 parent) {
		super(parent);
		Projection.setProjection(new Equirectangular());
	}
	
	@Override
	protected void method_25426() {
		super.method_25426();
		
		method_25411(new class_4185(field_22789 / 2 - 155, field_22790 / 6 + 84, 150, 20,
				new class_2585("Show Circle: " + (Equirectangular.drawCircle ? "ON" : "OFF")), (buttonWidget) -> {
					Equirectangular.drawCircle = !Equirectangular.drawCircle;
					buttonWidget.method_25355(new class_2585("Show Circle: " + (Equirectangular.drawCircle ? "ON" : "OFF")));
					ConfigManager.saveConfig();
				}));
		method_25411(new class_4185(field_22789 / 2 - 155, field_22790 / 6 + 132, 150, 20,
				new class_2585("Stabilize Pitch: " + (Equirectangular.stabilizePitch ? "ON" : "OFF")), (buttonWidget) -> {
					Equirectangular.stabilizePitch = !Equirectangular.stabilizePitch;
					buttonWidget.method_25355(new class_2585("Stabilize Pitch: " + (Equirectangular.stabilizePitch ? "ON" : "OFF")));
					ConfigManager.saveConfig();
				}));
		method_25411(new class_4185(field_22789 / 2 + 5, field_22790 / 6 + 132, 150, 20,
				new class_2585("Stabilize Yaw: " + (Equirectangular.stabilizeYaw ? "ON" : "OFF")), (buttonWidget) -> {
					Equirectangular.stabilizeYaw = !Equirectangular.stabilizeYaw;
					buttonWidget.method_25355(new class_2585("Stabilize Yaw: " + (Equirectangular.stabilizeYaw ? "ON" : "OFF")));
					ConfigManager.saveConfig();
				}));
	}
}
