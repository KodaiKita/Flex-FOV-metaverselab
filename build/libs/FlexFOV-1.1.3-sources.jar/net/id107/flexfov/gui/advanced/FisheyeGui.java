package net.id107.flexfov.gui.advanced;

import net.id107.flexfov.ConfigManager;
import net.id107.flexfov.projection.Fisheye;
import net.id107.flexfov.projection.Projection;
import net.minecraft.class_2585;
import net.minecraft.class_4067;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class FisheyeGui extends AdvancedGui {
	
	public FisheyeGui(class_437 parent) {
		super(parent);
		Projection.setProjection(new Fisheye());
	}
	
	@Override
	protected void method_25426() {
		super.method_25426();
		
		class_4185 button = new class_4185(field_22789 / 2 - 190, field_22790 / 6 + 60, 76, 20,
				new class_2585("Orthographic"), (buttonWidget) -> {
					Fisheye.fisheyeType = 0;
					field_22787.method_1507(new FisheyeGui(parentScreen));
				});
		if (Fisheye.fisheyeType == 0) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 - 114, field_22790 / 6 + 60, 76, 20,
				new class_2585("Thoby"), (buttonWidget) -> {
					Fisheye.fisheyeType = 1;
					field_22787.method_1507(new FisheyeGui(parentScreen));
				});
		if (Fisheye.fisheyeType == 1) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 - 38, field_22790 / 6 + 60, 76, 20,
				new class_2585("Equisolid"), (buttonWidget) -> {
					Fisheye.fisheyeType = 2;
					field_22787.method_1507(new FisheyeGui(parentScreen));
				});
		if (Fisheye.fisheyeType == 2) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 + 38, field_22790 / 6 + 60, 76, 20,
				new class_2585("Equidistant"), (buttonWidget) -> {
					Fisheye.fisheyeType = 3;
					field_22787.method_1507(new FisheyeGui(parentScreen));
				});
		if (Fisheye.fisheyeType == 3) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		button = new class_4185(field_22789 / 2 + 114, field_22790 / 6 + 60, 76, 20,
				new class_2585("Stereographic"), (buttonWidget) -> {
					Fisheye.fisheyeType = 4;
					field_22787.method_1507(new FisheyeGui(parentScreen));
				});
		if (Fisheye.fisheyeType == 4) {
			button.field_22763 = false;
		}
		method_25411(button);
		
		int fovSliderLimit = 360;
		if (Fisheye.fisheyeType == 1) fovSliderLimit = (int)Math.ceil(fovSliderLimit*0.713); //Thoby 256.68 degrees, slider goes up to 257
		if (Fisheye.fisheyeType == 0) fovSliderLimit = 180; //Orthographic
		final int finalSliderLimit = fovSliderLimit;
		class_4067 FOV = new class_4067("fisheyeFov", 0, fovSliderLimit, 1,
				(gameOptions) -> {return Math.min(finalSliderLimit, Projection.getProjection().getFovX());},
				(gameOptions, number) -> {Projection.fov = number; ConfigManager.saveConfig();},
				(gameOptions, doubleOption) -> {return new class_2585("FOV: " + (int)Math.min(finalSliderLimit, Projection.getProjection().getFovX()));});
		method_25411(FOV.method_18520(field_22787.field_1690, field_22789 / 2 - 180, field_22790 / 6 + 132, fovSliderLimit));
		
		method_25411(new class_4185(field_22789 / 2 - 155, field_22790 / 6 + 84, 150, 20,
				new class_2585("Background Color: " + (Projection.skyBackground ? "Sky" : "Black")), (buttonWidget) -> {
					Projection.skyBackground = !Projection.skyBackground;
					buttonWidget.method_25355(new class_2585("Background Color: " + (Projection.skyBackground ? "Sky" : "Black")));
					ConfigManager.saveConfig();
				}));
		method_25411(new class_4185(field_22789 / 2 - 155, field_22790 / 6 + 108, 150, 20,
				new class_2585("Full Frame: " + (Fisheye.fullFrame ? "ON" : "OFF")), (buttonWidget) -> {
					Fisheye.fullFrame = !Fisheye.fullFrame;
					buttonWidget.method_25355(new class_2585("Full Frame: " + (Fisheye.fullFrame ? "ON" : "OFF")));
					ConfigManager.saveConfig();
				}));
	}
}
