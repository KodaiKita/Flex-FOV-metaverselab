package net.id107.flexfov.gui.advanced;

import net.id107.flexfov.ConfigManager;
import net.id107.flexfov.projection.Cylinder;
import net.id107.flexfov.projection.Projection;
import net.minecraft.class_2585;
import net.minecraft.class_4067;
import net.minecraft.class_437;

public class CylinderGui extends AdvancedGui {

	public CylinderGui(class_437 parent) {
		super(parent);
		Projection.setProjection(new Cylinder());
	}
	
	@Override
	protected void method_25426() {
		super.method_25426();
		
		class_4067 FOVX = new class_4067("cylinderFovX", 0, 360, 1,
				(gameOptions) -> {return Projection.getProjection().getFovX();},
				(gameOptions, number) -> {Projection.fov = number; ConfigManager.saveConfig();},
				(gameOptions, doubleOption) -> {return new class_2585("Horizontal FOV: " + Math.round(Projection.getProjection().getFovX()));});
		method_25411(FOVX.method_18520(field_22787.field_1690, field_22789 / 2 - 180, field_22790 / 6 + 60, 360));
		
		class_4067 FOVY = new class_4067("cylinderFovY", 0, 180, 1,
				(gameOptions) -> {return Projection.getProjection().getFovY();},
				(gameOptions, number) -> {Cylinder.fovy = number; ConfigManager.saveConfig();},
				(gameOptions, doubleOption) -> {return new class_2585("Vertical FOV: " + Math.round(Projection.getProjection().getFovY()));});
		method_25411(FOVY.method_18520(field_22787.field_1690, field_22789 / 2 - 180, field_22790 / 6 + 84, 180));
	}
}
