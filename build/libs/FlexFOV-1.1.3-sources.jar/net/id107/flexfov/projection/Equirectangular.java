package net.id107.flexfov.projection;

import org.lwjgl.opengl.GL20;

import net.id107.flexfov.Reader;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_5498;

public class Equirectangular extends Projection {

	public static boolean drawCircle = false;
	public static boolean stabilizePitch = false;
	public static boolean stabilizeYaw = false;
	
	@Override
	public String getFragmentShader() {
		return Reader.read("flexfov:shaders/equirectangular.fs");
	}
	
	@Override
	public void loadUniforms(float tickDelta) {
		super.loadUniforms(tickDelta);
		
		class_310 mc = class_310.method_1551();
		int shaderProgram = getShaderProgram();
		
		int circleUniform = GL20.glGetUniformLocation(shaderProgram, "drawCircle");
		GL20.glUniform1i(circleUniform, (drawCircle && mc.field_1755 == null) ? 1 : 0);
		
		class_1297 entity = class_310.method_1551().method_1560();
		float pitch = 0;
		float yaw = 0;
		if (stabilizePitch) {
			pitch = entity.field_6004 + (entity.field_5965 - entity.field_6004) * tickDelta;
		}
		if (stabilizeYaw) {
			yaw = entity.field_5982 + (entity.field_6031 - entity.field_5982) * tickDelta;
		}
		if (mc.field_1690.method_31044() == class_5498.field_26666) {
			pitch = -pitch;
		}
		
		int angleUniform = GL20.glGetUniformLocation(shaderProgram, "rotation");
		GL20.glUniform2f(angleUniform, yaw, pitch);
	}
	
	@Override
	public double getFovX() {
		return 360;
	}
	
	@Override
	public double getFovY() {
		return 180;
	}
}
