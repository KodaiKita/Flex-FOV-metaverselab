package net.id107.flexfov.projection;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import com.mojang.blaze3d.systems.RenderSystem;

import net.id107.flexfov.BufferManager;
import net.id107.flexfov.Reader;
import net.id107.flexfov.ShaderManager;
import net.id107.flexfov.gui.SettingsGui;
import net.minecraft.class_1041;
import net.minecraft.class_1158;
import net.minecraft.class_1159;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_4492;
import net.minecraft.class_4493;
import net.minecraft.class_4587;

public abstract class Projection {
	
	private static Projection currentProjection;
	private static ShaderManager shader = new ShaderManager();
	
	public static float backgroundRed;
	public static float backgroundGreen;
	public static float backgroundBlue;
	
	public static double fov = 140f;
	public static int antialiasing = 16;
	public static boolean skyBackground = true;
	public static float zoom = 0;
	public static boolean resizeGui;
	
	protected int renderPass;
	
	private static boolean hudHidden;
	private static float tickDelta;
	
	private static int screenWidth;
	private static int screenHeight;
	
	public static Projection getProjection() {
		if (currentProjection == null) {
			SettingsGui.getGui(null);
		}
		return currentProjection;
	}
	
	public static void setProjection(Projection projection) {
		currentProjection = projection;
		if (shader != null) {
			shader.deleteShaderProgram();
			shader.createShaderProgram(projection);
		}
	}
	
	public String getVertexShader() {
		return Reader.read("flexfov:shaders/quad.vs");
	}
	
	public abstract String getFragmentShader();
	
	public void renderWorld(float tickDelta, long startTime, boolean tick) {
		class_310 mc = class_310.method_1551();
		Projection.tickDelta = tickDelta;
		int displayWidth = mc.method_22683().method_4480();
		int displayHeight = mc.method_22683().method_4507();
		hudHidden = mc.field_1690.field_1842;
		
		if (BufferManager.getFramebuffer() == null) {
			BufferManager.createFramebuffer();
			shader.createShaderProgram(getProjection());
			screenWidth = displayWidth;
			screenHeight = displayHeight;
		}
		
		if (screenWidth != displayWidth || screenHeight != displayHeight) {
			shader.deleteShaderProgram();
			BufferManager.deleteFramebuffer();
			BufferManager.createFramebuffer();
			shader.createShaderProgram(getProjection());
			screenWidth = displayWidth;
			screenHeight = displayHeight;
		}
		
		if (Math.max(getFovX(), getFovY()) > 90 || zoom < 0) {
			for (renderPass = 1; renderPass < 5; renderPass++) {
				GL11.glViewport(0, 0, displayWidth, displayHeight);
				mc.field_1769.method_3292();
				mc.field_1773.method_3188(tickDelta, startTime, new class_4587());
				saveRenderPass();
			}
			if (Math.max(getFovX(), getFovY()) > 250 || zoom < 0) {
				renderPass = 5;
				GL11.glViewport(0, 0, displayWidth, displayHeight);
				mc.field_1769.method_3292();
				mc.field_1773.method_3188(tickDelta, startTime, new class_4587());
				saveRenderPass();
			}
		}
		renderPass = 0;
		GL11.glViewport(0, 0, displayWidth, displayHeight);
		mc.field_1769.method_3292();
		
		mc.field_1690.field_1842 = hudHidden;
	}
	
	public void rotateCamera(class_4587 matrixStack) {
		class_1159 matrix;
		switch (renderPass) {
		case 0:
			break;
		case 1:
			matrix = new class_1159(new class_1158(0, 0.707106781f, 0, 0.707106781f)); //look right
			matrixStack.method_23760().method_23761().method_22672(matrix);
			break;
		case 2:
			matrix = new class_1159(new class_1158(0, -0.707106781f, 0, 0.707106781f)); //look left
			matrixStack.method_23760().method_23761().method_22672(matrix);
			break;
		case 3:
			matrix = new class_1159(new class_1158(0.707106781f, 0, 0, 0.707106781f)); //look down
			matrixStack.method_23760().method_23761().method_22672(matrix);
			break;
		case 4:
			matrix = new class_1159(new class_1158(-0.707106781f, 0, 0, 0.707106781f)); //look up
			matrixStack.method_23760().method_23761().method_22672(matrix);
			break;
		case 5:
			matrix = new class_1159(new class_1158(0, -1, 0, 0)); //look back
			matrixStack.method_23760().method_23761().method_22672(matrix);
			break;
		}
	}
	
	public void saveRenderPass() {
		if (getResizeGui() && renderPass == 0) {
			class_310 mc = class_310.method_1551();
			class_1041 window = mc.method_22683();
			RenderSystem.matrixMode(5889);
			RenderSystem.loadIdentity();
			RenderSystem.ortho(0.0D, (double)window.method_4489() / window.method_4495(), (double)window.method_4506() / window.method_4495(), 0.0D, 1000.0D, 3000.0D);
			RenderSystem.matrixMode(5888);
			RenderSystem.loadIdentity();
			RenderSystem.translatef(0.0F, 0.0F, -2000.0F);
			RenderSystem.defaultAlphaFunc();
			RenderSystem.clear(256, class_310.field_1703);
			class_4587 matrixStack = new class_4587();
			mc.field_1705.method_1753(matrixStack, tickDelta);
			RenderSystem.clear(256, class_310.field_1703);
			if (mc.field_1755 != null) {
				int i = (int)(mc.field_1729.method_1603() * (double)mc.method_22683().method_4486() / (double)mc.method_22683().method_4480());
				int j = (int)(mc.field_1729.method_1604() * (double)mc.method_22683().method_4502() / (double)mc.method_22683().method_4507());
				mc.field_1755.method_25394(matrixStack, i, j, mc.method_1534());
			}
		}
		
		class_276 defaultFramebuffer = class_310.method_1551().method_1522();
		class_276 targetFramebuffer = BufferManager.getFramebuffer();
		
		class_4493.method_22042(class_4492.field_20457, targetFramebuffer.field_1476);
		GL11.glViewport(0, 0, targetFramebuffer.field_1482, targetFramebuffer.field_1481);
		class_4493.method_21951(class_4492.field_20457, class_4492.field_20459,
				GL11.GL_TEXTURE_2D, BufferManager.framebufferTextures[renderPass], 0);
		
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glPushMatrix();
		GL11.glLoadIdentity();
		GL11.glOrtho(-1, 1, -1, 1, -1, 1);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glPushMatrix();
		GL11.glLoadIdentity();
		
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, defaultFramebuffer.method_30277());
		GL11.glBegin(GL11.GL_QUADS);
		{
			GL11.glTexCoord2f(BufferManager.getMinX(), BufferManager.getMinY());
			GL11.glVertex2f(-1, -1);
			GL11.glTexCoord2f(BufferManager.getMaxX(), BufferManager.getMinY());
			GL11.glVertex2f(1, -1);
			GL11.glTexCoord2f(BufferManager.getMaxX(), BufferManager.getMaxY());
			GL11.glVertex2f(1, 1);
			GL11.glTexCoord2f(BufferManager.getMinX(), BufferManager.getMaxY());
			GL11.glVertex2f(-1, 1);
		}
		GL11.glEnd();
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
		
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glPopMatrix();
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glPopMatrix();
		
		class_4493.method_22042(class_4492.field_20457, defaultFramebuffer.field_1476);
	}
	
	public void loadUniforms(float tickDelta) {
		class_310 mc = class_310.method_1551();
		int shaderProgram = shader.getShaderProgram();
		int displayWidth = class_310.method_1551().method_22683().method_4480();
		int displayHeight = class_310.method_1551().method_22683().method_4507();
		GL20.glUseProgram(shaderProgram);
		
		int aaUniform = GL20.glGetUniformLocation(shaderProgram, "antialiasing");
		GL20.glUniform1i(aaUniform, getAntialiasing());
		int pixelOffestUniform;
		if (getAntialiasing() == 16) {
			float left = (-1f+0.25f)/displayWidth;
			float top = (-1f+0.25f)/displayHeight;
			float right = 0.5f/displayWidth;
			float bottom = 0.5f/displayHeight;
			for (int y = 0; y < 4; y++) {
				for (int x = 0; x < 4; x++) {
					pixelOffestUniform = GL20.glGetUniformLocation(shaderProgram, "pixelOffset[" + (y*4+x) + "]");
					GL20.glUniform2f(pixelOffestUniform, left + right*x, top + bottom*y);
				}
			}
		} else if (getAntialiasing() == 4) {
			pixelOffestUniform = GL20.glGetUniformLocation(shaderProgram, "pixelOffset[0]");
			GL20.glUniform2f(pixelOffestUniform, -0.5f/displayWidth, -0.5f/displayHeight);
			pixelOffestUniform = GL20.glGetUniformLocation(shaderProgram, "pixelOffset[1]");
			GL20.glUniform2f(pixelOffestUniform, 0.5f/displayWidth, -0.5f/displayHeight);
			pixelOffestUniform = GL20.glGetUniformLocation(shaderProgram, "pixelOffset[2]");
			GL20.glUniform2f(pixelOffestUniform, -0.5f/displayWidth, 0.5f/displayHeight);
			pixelOffestUniform = GL20.glGetUniformLocation(shaderProgram, "pixelOffset[3]");
			GL20.glUniform2f(pixelOffestUniform, 0.5f/displayWidth, 0.5f/displayHeight);
		} else { //if (getAntialiasing() == 1)
			pixelOffestUniform = GL20.glGetUniformLocation(shaderProgram, "pixelOffset[0]");
			GL20.glUniform2f(pixelOffestUniform, 0, 0);
		}
		
		int texUniform = GL20.glGetUniformLocation(shaderProgram, "texFront");
		GL20.glUniform1i(texUniform, 0);
		texUniform = GL20.glGetUniformLocation(shaderProgram, "texBack");
		GL20.glUniform1i(texUniform, 5);
		texUniform = GL20.glGetUniformLocation(shaderProgram, "texLeft");
		GL20.glUniform1i(texUniform, 2);
		texUniform = GL20.glGetUniformLocation(shaderProgram, "texRight");
		GL20.glUniform1i(texUniform, 1);
		texUniform = GL20.glGetUniformLocation(shaderProgram, "texTop");
		GL20.glUniform1i(texUniform, 4);
		texUniform = GL20.glGetUniformLocation(shaderProgram, "texBottom");
		GL20.glUniform1i(texUniform, 3);
		
		int fovxUniform = GL20.glGetUniformLocation(shaderProgram, "fovx");
		GL20.glUniform1f(fovxUniform, (float) getFovX());
		int fovyUniform = GL20.glGetUniformLocation(shaderProgram, "fovy");
		GL20.glUniform1f(fovyUniform, (float) getFovY());
		
		int backgroundUniform = GL20.glGetUniformLocation(shaderProgram, "backgroundColor");
		float backgroundColor[] = getBackgroundColor(false);
		if (backgroundColor != null) {
			GL20.glUniform4f(backgroundUniform, backgroundColor[0], backgroundColor[1], backgroundColor[2], 1);
		} else {
			GL20.glUniform4f(backgroundUniform, 0, 0, 0, 1);
		}
		
		int zoomUniform = GL20.glGetUniformLocation(shaderProgram, "zoom");
		GL20.glUniform1f(zoomUniform, (float)Math.pow(2, -zoom));
		
		int drawCursorUniform = GL20.glGetUniformLocation(shaderProgram, "drawCursor");
		GL20.glUniform1i(drawCursorUniform, (getResizeGui() && mc.field_1755 != null) ? 1 : 0);
		int cursorPosUniform = GL20.glGetUniformLocation(shaderProgram, "cursorPos");
		class_1041 window = mc.method_22683();
		float mouseX = (float)mc.field_1729.method_1603() / (float)window.method_4480();
		float mouseY = (float)mc.field_1729.method_1604() / (float)window.method_4507();
		mouseX = (mouseX - 0.5f) * window.method_4480() / (float)window.method_4507() + 0.5f;
		mouseX = Math.max(0, Math.min(1, mouseX));
		GL20.glUniform2f(cursorPosUniform, mouseX, 1-mouseY);
	}
	
	public void runShader(float tickDelta) {
		int displayWidth = class_310.method_1551().method_22683().method_4480();
		int displayHeight = class_310.method_1551().method_22683().method_4507();
		GL13.glActiveTexture(GL13.GL_TEXTURE2);
		int lightmap = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
		
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glPushMatrix();
		GL11.glLoadIdentity();
		GL11.glOrtho(-1, 1, -1, 1, -1, 1);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glPushMatrix();
		GL11.glLoadIdentity();
		
		for (int i = 0; i < BufferManager.framebufferTextures.length; i++) {
			GL13.glActiveTexture(GL13.GL_TEXTURE0+i);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, BufferManager.framebufferTextures[i]);
		}
		GL11.glViewport(0, 0, displayWidth, displayHeight);
		GL11.glBegin(GL11.GL_QUADS);
		{
			GL11.glTexCoord2f(0, 0);
			GL11.glVertex2f(-1, -1);
			GL11.glTexCoord2f(1, 0);
			GL11.glVertex2f(1, -1);
			GL11.glTexCoord2f(1, 1);
			GL11.glVertex2f(1, 1);
			GL11.glTexCoord2f(0, 1);
			GL11.glVertex2f(-1, 1);
		}
		GL11.glEnd();
		for (int i = BufferManager.framebufferTextures.length-1; i >= 0; i--) {
			GL13.glActiveTexture(GL13.GL_TEXTURE0+i);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
		}
		
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glPopMatrix();
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glPopMatrix();
		
		GL13.glActiveTexture(GL13.GL_TEXTURE2);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, lightmap);
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		
		GL20.glUseProgram(0);
	}
	
	protected int getShaderProgram() {
		return shader.getShaderProgram();
	}
	
	public static float getTickDelta() {
		return tickDelta;
	}
	
	public int getAntialiasing() {
		return antialiasing;
	}
	
	public float[] getBackgroundColor(boolean sky) {
		if (sky) {
			return new float[] {backgroundRed, backgroundGreen, backgroundBlue};
		} else {
			return null;
		}
	}
	
	public boolean getResizeGui() {
		return resizeGui && class_310.method_1551().field_1687 != null;
	}
	
	public boolean shouldRotateParticles() {
		return true;
	}
	
	public boolean shouldOverrideFOV() {
		return true;
	}
	
	public double getPassFOV(double fovIn) {
		return BufferManager.getFOV();
	}
	
	public double getFovX() {
		return fov;
	}
	
	public double getFovY() {
		double displayWidth = class_310.method_1551().method_22683().method_4480();
		double displayHeight = class_310.method_1551().method_22683().method_4507();
		return getFovX()*displayHeight/displayWidth;
	}
}
