package net.id107.flexfov;

import java.io.IOException;
import java.io.InputStream;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

public class Reader {

	public static String read(String resourceIn) {
		class_3300 resourceManager = class_310.method_1551().method_1478();
		class_3298 resource = null;
		try {
			resource = resourceManager.method_14486(new class_2960(resourceIn));
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
		
		InputStream is = resource.method_14482();
		if (is == null) {
			System.out.println("Shader not found");
			return "";
		}
		
		StringBuilder sb = new StringBuilder();
		int i;
		
		try {
			i = is.read();
			while (i != -1) {
				sb.append((char) i);
				i = is.read();
			}
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
		
		return sb.toString();
	}
}
