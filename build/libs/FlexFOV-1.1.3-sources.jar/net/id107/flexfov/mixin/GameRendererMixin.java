package net.id107.flexfov.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.id107.flexfov.projection.Projection;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_757;

@Mixin(class_757.class)
public abstract class GameRendererMixin {
	@Shadow final class_310 client;
	@Shadow boolean renderingPanorama;
	private boolean renderingPanoramaTemp;
	private double fovTemp;
	
	public GameRendererMixin() {
		client = null;
	}
	
	@Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)D", at = @At(value = "RETURN", ordinal = 0), cancellable = true)
	private void panoramaFov(CallbackInfoReturnable<Double> callbackInfo) {
		callbackInfo.setReturnValue((double)Projection.getProjection().getPassFOV(90));
	}
	
	@Inject(method = "render(FJZ)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/GameRenderer;renderWorld(FJLnet/minecraft/client/util/math/MatrixStack;)V", ordinal = 0))
	private void renderPre(float tickDelta, long startTime, boolean tick, CallbackInfo callbackInfo) {
		renderingPanoramaTemp = renderingPanorama;
		renderingPanorama = Projection.getProjection().shouldOverrideFOV();
		fovTemp = client.field_1690.field_1826;
		client.field_1690.field_1826 = Projection.getProjection().getPassFOV(fovTemp);
		Projection.getProjection().renderWorld(tickDelta, startTime, tick);
	}
	
	@Inject(method = "render(FJZ)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;isIntegratedServerRunning()Z", ordinal = 0))
	private void renderPost(float tickDelta, long startTime, boolean tick, CallbackInfo callbackInfo) {
		renderingPanorama = renderingPanoramaTemp;
		client.field_1690.field_1826 = fovTemp;
		Projection.getProjection().saveRenderPass();
		Projection.getProjection().loadUniforms(tickDelta);
		Projection.getProjection().runShader(tickDelta);
	}
	
	@ModifyVariable(method = "renderWorld(FJLnet/minecraft/client/util/math/MatrixStack;)V",
			ordinal = 1,
			at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/GameRenderer;bobViewWhenHurt(Lnet/minecraft/client/util/math/MatrixStack;F)V", ordinal = 0))
	private class_4587 updateCamera(class_4587 matrixStack) {
		Projection.getProjection().rotateCamera(matrixStack);
		return matrixStack;
	}
	
	@Redirect(method = "render(FJZ)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;render(Lnet/minecraft/client/util/math/MatrixStack;F)V"))
	private void renderHud(class_329 inGameHud, class_4587 matrixStack, float tickDelta) {
		if (!Projection.getProjection().getResizeGui()) {
			inGameHud.method_1753(matrixStack, tickDelta);
		}
	}
	
	@Redirect(method = "render(FJZ)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/Screen;render(Lnet/minecraft/client/util/math/MatrixStack;IIF)V"))
	private void renderCurrentScreen(class_437 currentScreen, class_4587 matrixStack, int mouseX, int mouseY, float delta) {
		if (!Projection.getProjection().getResizeGui()) {
			currentScreen.method_25394(matrixStack, mouseX, mouseY, delta);
		}
	}
}
