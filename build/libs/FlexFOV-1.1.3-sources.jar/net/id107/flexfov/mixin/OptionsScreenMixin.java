package net.id107.flexfov.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.id107.flexfov.gui.SettingsGui;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_4185;
import net.minecraft.class_429;
import net.minecraft.class_437;

@Mixin(class_429.class)
public abstract class OptionsScreenMixin extends class_437 {
	
	public OptionsScreenMixin(class_2561 text) {
		super(text);
	}
	
	@Inject(method = "init()V", at = @At(value = "TAIL"))
	private void newButton(CallbackInfo callbackInfo) {
		method_25411(new class_4185(field_22789 / 2 - 155, field_22790 / 6 + 15, 150, 20, new class_2585("Flex FOV Settings"), (buttonWidget) -> {
			field_22787.method_1507(SettingsGui.getGui(this));
		}));
	}
}
