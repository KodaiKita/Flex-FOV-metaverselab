package net.id107.flexfov.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.id107.flexfov.projection.Projection;
import net.minecraft.class_310;
import net.minecraft.class_437;

@Mixin(class_437.class)
public class ScreenMixin {

	@Inject(method = "renderBackground(Lnet/minecraft/client/util/math/MatrixStack;)V", at = @At(value = "HEAD"), cancellable = true)
	private void render(CallbackInfo callbackInfo) {
		if (Projection.getProjection().getResizeGui() && class_310.method_1551().field_1687 != null) {
			callbackInfo.cancel();
		}
	}
}
