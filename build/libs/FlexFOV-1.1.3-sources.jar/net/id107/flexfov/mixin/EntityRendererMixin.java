package net.id107.flexfov.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import net.id107.flexfov.projection.Projection;
import net.minecraft.class_1158;
import net.minecraft.class_1160;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_897;

@Mixin(class_897.class)
public class EntityRendererMixin {

	private class_1297 currentEntity;
	
	@ModifyVariable(method = "renderLabelIfPresent(Lnet/minecraft/entity/Entity;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
			at = @At(value = "HEAD"))
	private class_1297 getEntity(class_1297 entity) {
		currentEntity = entity;
		return entity;
	}
	
	@ModifyVariable(method = "renderLabelIfPresent(Lnet/minecraft/entity/Entity;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
			at = @At(value = "INVOKE", ordinal = 0,
			target = "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lnet/minecraft/util/math/Quaternion;)V"))
	private class_4587 rotateNameplatePre(class_4587 matrixStack) {
		if (Projection.getProjection().shouldRotateParticles()) {
			matrixStack.method_22903();
		}
		return matrixStack;
	}
	
	@ModifyVariable(method = "renderLabelIfPresent(Lnet/minecraft/entity/Entity;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
			at = @At(value = "INVOKE", ordinal = 0,
			target = "Lnet/minecraft/client/util/math/MatrixStack;scale(FFF)V"))
	private class_4587 rotateNameplate(class_4587 matrixStack) {
		if (Projection.getProjection().shouldRotateParticles()) {
			matrixStack.method_22909();
			class_310 mc = class_310.method_1551();
			class_1297 camera = mc.field_1719;
			class_243 cameraPos = camera.method_19538().method_1023(camera.field_6014, camera.field_6036, camera.field_5969).method_1021(Projection.getTickDelta()).method_1019(new class_243(camera.field_6014, camera.field_6036, camera.field_5969));
			class_243 entityPos = new class_243(currentEntity.method_23317(), currentEntity.method_23318(), currentEntity.method_23321()).method_1020(new class_243(currentEntity.field_6014, currentEntity.field_6036, currentEntity.field_5969)).method_1021(Projection.getTickDelta()).method_1019(new class_243(currentEntity.field_6014, currentEntity.field_6036, currentEntity.field_5969));
			class_243 dir = cameraPos.method_1020(entityPos).method_1029();
			class_1158 quaternion = new class_1158(0, 0, 0, 1);
			quaternion.method_4925(class_1160.field_20705.method_23626((float)Math.atan2(-dir.field_1352, -dir.field_1350)));
			quaternion.method_4925(class_1160.field_20703.method_23626((float)Math.asin(dir.field_1351)));
			matrixStack.method_22907(quaternion);
		}
		return matrixStack;
	}
}
