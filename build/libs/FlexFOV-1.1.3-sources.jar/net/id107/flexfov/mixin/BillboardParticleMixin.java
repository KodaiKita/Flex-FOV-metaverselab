package net.id107.flexfov.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import net.id107.flexfov.projection.Projection;
import net.minecraft.class_1158;
import net.minecraft.class_1160;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3940;
import net.minecraft.class_638;
import net.minecraft.class_703;

@Mixin(value = class_3940.class, priority = 1500)
public abstract class BillboardParticleMixin extends class_703 {

	protected BillboardParticleMixin(class_638 world, double x, double y, double z) {
		super(world, x, y, z);
	}

	@ModifyVariable(method = "buildGeometry(Lnet/minecraft/client/render/VertexConsumer;Lnet/minecraft/client/render/Camera;F)V",
			ordinal = 0,
			at = @At(value = "INVOKE_ASSIGN", ordinal = 0,
			target = "Lnet/minecraft/client/render/Camera;getRotation()Lnet/minecraft/util/math/Quaternion;"))
	private class_1158 rotateParticle(class_1158 quaternion) {
		if (Projection.getProjection().shouldRotateParticles()) {
			class_310 mc = class_310.method_1551();
			class_1297 camera = mc.field_1719;
			class_243 cameraPos = camera.method_19538().method_1023(camera.field_6014, camera.field_6036, camera.field_5969).method_1021(Projection.getTickDelta()).method_1019(new class_243(camera.field_6014, camera.field_6036, camera.field_5969));
			class_243 particlePos = new class_243(field_3874, field_3854, field_3871).method_1020(new class_243(field_3858, field_3838, field_3856)).method_1021(Projection.getTickDelta()).method_1019(new class_243(field_3858, field_3838, field_3856));
			class_243 dir = cameraPos.method_1020(particlePos).method_1029();
			quaternion.method_23758(0, 0, 0, 1);
			quaternion.method_4925(class_1160.field_20705.method_23626((float)Math.atan2(-dir.field_1352, -dir.field_1350)));
			quaternion.method_4925(class_1160.field_20703.method_23626((float)Math.asin(dir.field_1351)));
		}
		return quaternion;
	}
}
